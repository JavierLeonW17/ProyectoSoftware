
  # Crear gestor de tickets

  This is a code bundle for Crear gestor de tickets. The original project is available at https://www.figma.com/design/S2qw1F5qM2rwqtcQ3SOKuC/Crear-gestor-de-tickets.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  