import { RolUsuario } from '../types/usuario';

export const Permisos = {
  // Permisos de tickets
  CREAR_TICKET: ['administrador', 'agente', 'usuario'],
  VER_TODOS_TICKETS: ['administrador', 'agente'],
  VER_PROPIOS_TICKETS: ['administrador', 'agente', 'usuario'],
  ASIGNAR_TICKET: ['administrador', 'agente'],
  CAMBIAR_ESTADO_TICKET: ['administrador', 'agente'],
  COMENTAR_TICKET: ['administrador', 'agente', 'usuario'],
  VER_SLA: ['administrador'],

  // Permisos de usuarios
  GESTIONAR_USUARIOS: ['administrador'],
  VER_USUARIOS: ['administrador', 'agente'],

  // Permisos de reportes
  VER_REPORTES: ['administrador'],
  VER_LOGS: ['administrador'],
};

export function tienePermiso(rol: RolUsuario, permiso: string[]): boolean {
  return permiso.includes(rol);
}

export function puedeAsignarTicket(rol: RolUsuario): boolean {
  return tienePermiso(rol, Permisos.ASIGNAR_TICKET);
}

export function puedeCambiarEstado(rol: RolUsuario, ticketAsignadoA?: string, emailUsuario?: string): boolean {
  if (rol === 'administrador') return true;
  if (rol === 'agente' && ticketAsignadoA === emailUsuario) return true;
  return false;
}

export function puedeVerTodosTickets(rol: RolUsuario): boolean {
  return tienePermiso(rol, Permisos.VER_TODOS_TICKETS);
}

export function puedeGestionarUsuarios(rol: RolUsuario): boolean {
  return tienePermiso(rol, Permisos.GESTIONAR_USUARIOS);
}
