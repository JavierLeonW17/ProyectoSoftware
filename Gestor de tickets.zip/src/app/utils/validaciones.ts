import { Ticket } from '../types/ticket';

export function validarTicketDuplicado(
  tickets: Ticket[],
  area: string,
  creadoPor: string,
  excluirId?: number
): { duplicado: boolean; ticketExistente?: Ticket } {
  const ticketActivo = tickets.find(
    (t) =>
      t.area === area &&
      t.creadoPor === creadoPor &&
      t.estado !== 'cerrado' &&
      t.id !== excluirId
  );

  if (ticketActivo) {
    return { duplicado: true, ticketExistente: ticketActivo };
  }

  return { duplicado: false };
}

export function generarNumeroTicket(): string {
  const fecha = new Date();
  const año = fecha.getFullYear();
  const mes = String(fecha.getMonth() + 1).padStart(2, '0');
  const dia = String(fecha.getDate()).padStart(2, '0');
  const aleatorio = Math.floor(Math.random() * 10000).toString().padStart(4, '0');

  return `TKT-${año}${mes}${dia}-${aleatorio}`;
}

export function calcularTiempoResolucion(fechaEnCurso: string, fechaCierre: string): number {
  const inicio = new Date(fechaEnCurso).getTime();
  const fin = new Date(fechaCierre).getTime();
  const diferencia = fin - inicio;

  return Math.floor(diferencia / (1000 * 60)); // Retorna minutos
}

export function verificarSLA(tiempoResolucionMinutos: number, prioridad: string): boolean {
  // SLA en minutos según prioridad
  const slaLimites = {
    alta: 120, // 2 horas
    media: 480, // 8 horas
    baja: 1440, // 24 horas
  };

  const limite = slaLimites[prioridad as keyof typeof slaLimites] || 1440;
  return tiempoResolucionMinutos > limite;
}

export function formatearTiempoResolucion(minutos: number): string {
  const horas = Math.floor(minutos / 60);
  const mins = minutos % 60;

  if (horas > 0) {
    return `${horas}h ${mins}m`;
  }
  return `${mins}m`;
}
