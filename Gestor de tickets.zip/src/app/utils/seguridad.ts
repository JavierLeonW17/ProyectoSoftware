import { LogAcceso } from '../types/usuario';

// Simulación de hash de contraseña (en producción usar bcrypt)
export function hashPassword(password: string): string {
  // NOTA: Esto es solo para demostración. En producción usar bcrypt o similar
  return btoa(password + 'TECHHUB_SALT_2026');
}

export function verificarPassword(password: string, hash: string): boolean {
  return hashPassword(password) === hash;
}

// Detección de accesos sospechosos
export function detectarAccesoSospechoso(
  email: string,
  logsRecientes: LogAcceso[]
): { sospechoso: boolean; razon?: string } {
  const intentosFallidos = logsRecientes.filter(
    (log) =>
      log.email === email &&
      !log.exitoso &&
      new Date().getTime() - new Date(log.fechaHora).getTime() < 15 * 60 * 1000 // Últimos 15 minutos
  );

  // Más de 3 intentos fallidos en 15 minutos
  if (intentosFallidos.length >= 3) {
    return {
      sospechoso: true,
      razon: `${intentosFallidos.length} intentos fallidos en 15 minutos`,
    };
  }

  // Verificar acceso desde diferentes IPs en corto tiempo
  const accesosRecientes = logsRecientes.filter(
    (log) =>
      log.email === email &&
      log.exitoso &&
      new Date().getTime() - new Date(log.fechaHora).getTime() < 5 * 60 * 1000 // Últimos 5 minutos
  );

  const ipsUnicas = new Set(accesosRecientes.map((log) => log.direccionIP));
  if (ipsUnicas.size > 2) {
    return {
      sospechoso: true,
      razon: `Acceso desde ${ipsUnicas.size} IPs diferentes en 5 minutos`,
    };
  }

  return { sospechoso: false };
}

export function registrarLog(
  logsActuales: LogAcceso[],
  usuarioId: number,
  email: string,
  exitoso: boolean,
  sospechoso: boolean = false,
  razon?: string
): LogAcceso[] {
  const nuevoLog: LogAcceso = {
    id: logsActuales.length + 1,
    usuarioId,
    email,
    fechaHora: new Date().toISOString(),
    exitoso,
    direccionIP: generarIPSimulada(),
    navegador: obtenerNavegador(),
    sospechoso,
    razon,
  };

  return [nuevoLog, ...logsActuales];
}

function generarIPSimulada(): string {
  return `192.168.${Math.floor(Math.random() * 255)}.${Math.floor(Math.random() * 255)}`;
}

function obtenerNavegador(): string {
  const userAgent = navigator.userAgent;
  if (userAgent.includes('Chrome')) return 'Chrome';
  if (userAgent.includes('Firefox')) return 'Firefox';
  if (userAgent.includes('Safari')) return 'Safari';
  if (userAgent.includes('Edge')) return 'Edge';
  return 'Desconocido';
}
