import { useState } from 'react';
import { InicioSesionMejorado } from './components/InicioSesionMejorado';
import { BarraLateral } from './components/BarraLateral';
import { PanelPrincipal } from './components/PanelPrincipal';
import { Usuario, LogAcceso } from './types/usuario';
import { Ticket } from './types/ticket';
import { usuariosIniciales, logsIniciales } from './data/usuariosIniciales';

export default function App() {
  const [sesionIniciada, setSesionIniciada] = useState(false);
  const [usuarioActual, setUsuarioActual] = useState<Usuario | null>(null);
  const [usuarios, setUsuarios] = useState<Usuario[]>(usuariosIniciales);
  const [logs, setLogs] = useState<LogAcceso[]>(logsIniciales);
  const [vistaActual, setVistaActual] = useState('panel-principal');
  const [tickets, setTickets] = useState<Ticket[]>([]);

  const manejarInicioSesion = (usuario: Usuario) => {
    setSesionIniciada(true);
    setUsuarioActual(usuario);

    // Actualizar último acceso
    const usuariosActualizados = usuarios.map(u =>
      u.id === usuario.id
        ? { ...u, ultimoAcceso: new Date().toISOString() }
        : u
    );
    setUsuarios(usuariosActualizados);
  };

  const manejarCerrarSesion = () => {
    setSesionIniciada(false);
    setUsuarioActual(null);
    setVistaActual('panel-principal');
  };

  const manejarActualizarLogs = (nuevosLogs: LogAcceso[]) => {
    setLogs(nuevosLogs);
  };

  if (!sesionIniciada || !usuarioActual) {
    return (
      <InicioSesionMejorado
        onIniciarSesion={manejarInicioSesion}
        usuarios={usuarios}
        logs={logs}
        onActualizarLogs={manejarActualizarLogs}
      />
    );
  }

  return (
    <div className="flex h-screen bg-gray-50 overflow-hidden">
      <BarraLateral
        vistaActual={vistaActual}
        onCambiarVista={setVistaActual}
        onCerrarSesion={manejarCerrarSesion}
        usuarioActual={usuarioActual.email}
      />

      {vistaActual === 'panel-principal' && (
        <PanelPrincipal />
      )}

      {vistaActual === 'tickets' && (
        <div className="flex-1 bg-gray-50 overflow-auto p-8">
          <div className="mb-8">
            <h1 className="font-bold text-gray-900">Gestión de Tickets</h1>
            <p className="text-sm text-gray-600 mt-1">
              Rol: {usuarioActual.rol.charAt(0).toUpperCase() + usuarioActual.rol.slice(1)}
            </p>
          </div>
          <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
            <p className="text-gray-600">Vista de tickets próximamente...</p>
          </div>
        </div>
      )}

      {vistaActual === 'usuarios' && (
        <div className="flex-1 bg-gray-50 overflow-auto p-8">
          <div className="mb-8">
            <h1 className="font-bold text-gray-900">Gestión de Usuarios</h1>
            <p className="text-sm text-gray-600 mt-1">
              Administra los usuarios del sistema
            </p>
          </div>

          {usuarioActual.rol === 'administrador' ? (
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Nombre
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Email
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Rol
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Estado
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Último Acceso
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {usuarios.map((usuario) => (
                      <tr key={usuario.id} className="hover:bg-gray-50">
                        <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                          {usuario.nombre}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                          {usuario.email}
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                            usuario.rol === 'administrador'
                              ? 'bg-purple-100 text-purple-800'
                              : usuario.rol === 'agente'
                              ? 'bg-blue-100 text-blue-800'
                              : 'bg-gray-100 text-gray-800'
                          }`}>
                            {usuario.rol.charAt(0).toUpperCase() + usuario.rol.slice(1)}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap">
                          <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                            usuario.activo
                              ? 'bg-green-100 text-green-800'
                              : 'bg-red-100 text-red-800'
                          }`}>
                            {usuario.activo ? 'Activo' : 'Inactivo'}
                          </span>
                        </td>
                        <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                          {usuario.ultimoAcceso
                            ? new Date(usuario.ultimoAcceso).toLocaleString('es-ES')
                            : 'Nunca'}
                        </td>
                      </tr>
                    ))}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <p className="text-yellow-800">
                No tienes permisos para gestionar usuarios. Solo los administradores pueden acceder a esta sección.
              </p>
            </div>
          )}
        </div>
      )}

      {vistaActual === 'reportes' && (
        <div className="flex-1 bg-gray-50 overflow-auto p-8">
          <div className="mb-8">
            <h1 className="font-bold text-gray-900">Reportes y SLA</h1>
            <p className="text-sm text-gray-600 mt-1">
              Métricas de rendimiento y cumplimiento
            </p>
          </div>

          {usuarioActual.rol === 'administrador' ? (
            <div className="bg-white rounded-lg border border-gray-200 p-8 text-center">
              <p className="text-gray-600">Reportes SLA próximamente...</p>
            </div>
          ) : (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <p className="text-yellow-800">
                No tienes permisos para ver reportes. Solo los administradores pueden acceder a esta sección.
              </p>
            </div>
          )}
        </div>
      )}

      {vistaActual === 'logs' && (
        <div className="flex-1 bg-gray-50 overflow-auto p-8">
          <div className="mb-8">
            <h1 className="font-bold text-gray-900">Logs de Seguridad</h1>
            <p className="text-sm text-gray-600 mt-1">
              Monitoreo de accesos e intentos sospechosos
            </p>
          </div>

          {usuarioActual.rol === 'administrador' ? (
            <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
              <div className="overflow-x-auto">
                <table className="w-full">
                  <thead className="bg-gray-50 border-b border-gray-200">
                    <tr>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Fecha/Hora
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Email
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Estado
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        IP
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Navegador
                      </th>
                      <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase">
                        Sospechoso
                      </th>
                    </tr>
                  </thead>
                  <tbody className="bg-white divide-y divide-gray-200">
                    {logs.length === 0 ? (
                      <tr>
                        <td colSpan={6} className="px-6 py-8 text-center text-gray-500">
                          No hay logs registrados aún
                        </td>
                      </tr>
                    ) : (
                      logs.slice(0, 50).map((log) => (
                        <tr key={log.id} className={`hover:bg-gray-50 ${log.sospechoso ? 'bg-red-50' : ''}`}>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {new Date(log.fechaHora).toLocaleString('es-ES')}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {log.email}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            <span className={`px-2 py-1 text-xs font-medium rounded-full ${
                              log.exitoso
                                ? 'bg-green-100 text-green-800'
                                : 'bg-red-100 text-red-800'
                            }`}>
                              {log.exitoso ? 'Exitoso' : 'Fallido'}
                            </span>
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {log.direccionIP}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600">
                            {log.navegador}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap">
                            {log.sospechoso ? (
                              <div>
                                <span className="px-2 py-1 text-xs font-medium rounded-full bg-red-100 text-red-800">
                                  Sí
                                </span>
                                {log.razon && (
                                  <p className="text-xs text-red-600 mt-1">{log.razon}</p>
                                )}
                              </div>
                            ) : (
                              <span className="px-2 py-1 text-xs font-medium rounded-full bg-gray-100 text-gray-800">
                                No
                              </span>
                            )}
                          </td>
                        </tr>
                      ))
                    )}
                  </tbody>
                </table>
              </div>
            </div>
          ) : (
            <div className="bg-yellow-50 border border-yellow-200 rounded-lg p-4">
              <p className="text-yellow-800">
                No tienes permisos para ver logs de seguridad. Solo los administradores pueden acceder a esta sección.
              </p>
            </div>
          )}
        </div>
      )}

      {vistaActual === 'documentacion' && (
        <div className="flex-1 bg-gray-50 overflow-auto p-8">
          <h1 className="font-bold text-gray-900">Documentación</h1>
          <p className="text-sm text-gray-600 mt-1">Próximamente...</p>
        </div>
      )}

      {vistaActual === 'ayuda' && (
        <div className="flex-1 bg-gray-50 overflow-auto p-8">
          <h1 className="font-bold text-gray-900">Centro de Ayuda</h1>
          <p className="text-sm text-gray-600 mt-1">Próximamente...</p>
        </div>
      )}

      {vistaActual === 'configuracion' && (
        <div className="flex-1 bg-gray-50 overflow-auto p-8">
          <h1 className="font-bold text-gray-900">Configuración</h1>
          <p className="text-sm text-gray-600 mt-1">Próximamente...</p>
        </div>
      )}
    </div>
  );
}
