export type TicketStatus = 'abierto' | 'en-curso' | 'cerrado';
export type TicketPriority = 'baja' | 'media' | 'alta';
export type TicketTipo = 'problema' | 'solicitud';

export interface Comentario {
  id: number;
  ticketId: number;
  autor: string;
  autorRol: string;
  texto: string;
  fecha: string;
}

export interface CambioEstado {
  id: number;
  ticketId: number;
  estadoAnterior: TicketStatus;
  estadoNuevo: TicketStatus;
  fecha: string;
  usuario: string;
}

export interface Ticket {
  id: number;
  numeroTicket: string;
  asunto: string;
  descripcion: string;
  tipo: TicketTipo;
  area: string;
  prioridad: TicketPriority;
  estado: TicketStatus;
  creadoPor: string;
  asignadoA?: string;
  fechaCreacion: string;
  fechaAsignacion?: string;
  fechaEnCurso?: string;
  fechaCierre?: string;
  tiempoResolucionMinutos?: number;
  slaIncumplido?: boolean;
  comentarios: Comentario[];
  historialEstados: CambioEstado[];
}
