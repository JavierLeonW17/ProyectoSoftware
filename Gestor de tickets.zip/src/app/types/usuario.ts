export type RolUsuario = 'administrador' | 'agente' | 'usuario';

export interface Usuario {
  id: number;
  nombre: string;
  email: string;
  rol: RolUsuario;
  activo: boolean;
  fechaCreacion: string;
  ultimoAcceso?: string;
}

export interface LogAcceso {
  id: number;
  usuarioId: number;
  email: string;
  fechaHora: string;
  exitoso: boolean;
  direccionIP: string;
  navegador: string;
  sospechoso: boolean;
  razon?: string;
}
