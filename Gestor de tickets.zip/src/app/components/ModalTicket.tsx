import { useState, useEffect } from 'react';
import { X } from 'lucide-react';
import { Ticket, TicketStatus, TicketPriority } from '../types/ticket';

interface ModalTicketProps {
  estaAbierto: boolean;
  onCerrar: () => void;
  onGuardar: (ticket: Partial<Ticket>) => void;
  ticket?: Ticket | null;
  modo: 'crear' | 'editar';
}

export function ModalTicket({ estaAbierto, onCerrar, onGuardar, ticket, modo }: ModalTicketProps) {
  const [datosFormulario, setDatosFormulario] = useState({
    titulo: '',
    descripcion: '',
    prioridad: 'media' as TicketPriority,
    estado: 'nuevo' as TicketStatus,
    asignado: '',
    categoria: '',
  });

  useEffect(() => {
    if (modo === 'editar' && ticket) {
      setDatosFormulario({
        titulo: ticket.titulo,
        descripcion: ticket.descripcion,
        prioridad: ticket.prioridad,
        estado: ticket.estado,
        asignado: ticket.asignado,
        categoria: ticket.categoria || '',
      });
    } else {
      setDatosFormulario({
        titulo: '',
        descripcion: '',
        prioridad: 'media',
        estado: 'nuevo',
        asignado: '',
        categoria: '',
      });
    }
  }, [modo, ticket, estaAbierto]);

  const manejarEnvio = (e: React.FormEvent) => {
    e.preventDefault();
    onGuardar(datosFormulario);
    onCerrar();
  };

  if (!estaAbierto) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-2xl w-full max-h-[90vh] overflow-y-auto">
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <h2 className="font-semibold text-gray-900">
            {modo === 'crear' ? 'Crear Nuevo Ticket' : 'Editar Ticket'}
          </h2>
          <button onClick={onCerrar} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <form onSubmit={manejarEnvio} className="p-6 space-y-4">
          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Título *
            </label>
            <input
              type="text"
              required
              value={datosFormulario.titulo}
              onChange={(e) => setDatosFormulario({ ...datosFormulario, titulo: e.target.value })}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Ingrese el título del ticket"
            />
          </div>

          <div>
            <label className="block text-sm font-medium text-gray-700 mb-1">
              Descripción *
            </label>
            <textarea
              required
              value={datosFormulario.descripcion}
              onChange={(e) => setDatosFormulario({ ...datosFormulario, descripcion: e.target.value })}
              rows={4}
              className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              placeholder="Describa el problema o solicitud"
            />
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Prioridad *
              </label>
              <select
                value={datosFormulario.prioridad}
                onChange={(e) =>
                  setDatosFormulario({ ...datosFormulario, prioridad: e.target.value as TicketPriority })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="baja">Baja</option>
                <option value="media">Media</option>
                <option value="alta">Alta</option>
              </select>
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Estado
              </label>
              <select
                value={datosFormulario.estado}
                onChange={(e) =>
                  setDatosFormulario({ ...datosFormulario, estado: e.target.value as TicketStatus })
                }
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="nuevo">Nuevo</option>
                <option value="en-progreso">En Progreso</option>
                <option value="resuelto">Resuelto</option>
                <option value="cerrado">Cerrado</option>
              </select>
            </div>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Asignado a *
              </label>
              <input
                type="text"
                required
                value={datosFormulario.asignado}
                onChange={(e) => setDatosFormulario({ ...datosFormulario, asignado: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Nombre del responsable"
              />
            </div>

            <div>
              <label className="block text-sm font-medium text-gray-700 mb-1">
                Categoría
              </label>
              <input
                type="text"
                value={datosFormulario.categoria}
                onChange={(e) => setDatosFormulario({ ...datosFormulario, categoria: e.target.value })}
                className="w-full px-3 py-2 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-blue-500"
                placeholder="Ej: Hardware, Software, Red"
              />
            </div>
          </div>

          <div className="flex gap-3 pt-4 border-t border-gray-200">
            <button
              type="button"
              onClick={onCerrar}
              className="flex-1 px-4 py-2 border border-gray-300 rounded-md hover:bg-gray-50 transition-colors"
            >
              Cancelar
            </button>
            <button
              type="submit"
              className="flex-1 px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 transition-colors"
            >
              {modo === 'crear' ? 'Crear Ticket' : 'Guardar Cambios'}
            </button>
          </div>
        </form>
      </div>
    </div>
  );
}
