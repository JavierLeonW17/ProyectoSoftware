import { Home, Ticket, Users, Settings, BarChart3, FileText, HelpCircle, LogOut, Shield } from 'lucide-react';

interface BarraLateralProps {
  vistaActual: string;
  onCambiarVista: (vista: string) => void;
  onCerrarSesion: () => void;
  usuarioActual: string;
}

const elementosMenu = [
  { id: 'panel-principal', etiqueta: 'Panel Principal', icono: Home },
  { id: 'tickets', etiqueta: 'Tickets', icono: Ticket },
  { id: 'usuarios', etiqueta: 'Usuarios', icono: Users },
  { id: 'reportes', etiqueta: 'Reportes y SLA', icono: BarChart3 },
  { id: 'logs', etiqueta: 'Logs de Seguridad', icono: Shield },
  { id: 'documentacion', etiqueta: 'Documentación', icono: FileText },
];

const elementosInferiores = [
  { id: 'ayuda', etiqueta: 'Ayuda', icono: HelpCircle },
  { id: 'configuracion', etiqueta: 'Configuración', icono: Settings },
];

export function BarraLateral({ vistaActual, onCambiarVista, onCerrarSesion, usuarioActual }: BarraLateralProps) {
  const obtenerIniciales = (email: string) => {
    const nombre = email.split('@')[0];
    return nombre.substring(0, 2).toUpperCase();
  };

  return (
    <div className="w-64 bg-slate-900 text-white h-screen flex flex-col">
      {/* Logo/Encabezado */}
      <div className="p-6 border-b border-slate-800">
        <div className="flex items-center gap-3 mb-2">
          <div className="w-10 h-10 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-lg flex items-center justify-center">
            <span className="font-bold text-white">TH</span>
          </div>
          <h1 className="font-bold text-xl">TechHub Support</h1>
        </div>
        <p className="text-xs text-slate-400">Sistema de Gestión de Tickets</p>
      </div>

      {/* Menú Principal */}
      <nav className="flex-1 px-3 py-4 space-y-1">
        {elementosMenu.map((elemento) => {
          const Icono = elemento.icono;
          const estaActivo = vistaActual === elemento.id;
          return (
            <button
              key={elemento.id}
              onClick={() => onCambiarVista(elemento.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                estaActivo
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icono className="w-5 h-5" />
              <span className="text-sm font-medium">{elemento.etiqueta}</span>
            </button>
          );
        })}
      </nav>

      {/* Menú Inferior */}
      <div className="px-3 py-4 border-t border-slate-800 space-y-1">
        {elementosInferiores.map((elemento) => {
          const Icono = elemento.icono;
          const estaActivo = vistaActual === elemento.id;
          return (
            <button
              key={elemento.id}
              onClick={() => onCambiarVista(elemento.id)}
              className={`w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors ${
                estaActivo
                  ? 'bg-blue-600 text-white'
                  : 'text-slate-300 hover:bg-slate-800 hover:text-white'
              }`}
            >
              <Icono className="w-5 h-5" />
              <span className="text-sm font-medium">{elemento.etiqueta}</span>
            </button>
          );
        })}

        {/* Botón Cerrar Sesión */}
        <button
          onClick={onCerrarSesion}
          className="w-full flex items-center gap-3 px-3 py-2.5 rounded-lg transition-colors text-slate-300 hover:bg-red-600 hover:text-white"
        >
          <LogOut className="w-5 h-5" />
          <span className="text-sm font-medium">Cerrar Sesión</span>
        </button>
      </div>

      {/* Perfil de Usuario */}
      <div className="p-4 border-t border-slate-800">
        <div className="flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-full flex items-center justify-center">
            <span className="font-semibold">{obtenerIniciales(usuarioActual)}</span>
          </div>
          <div className="flex-1 min-w-0">
            <p className="text-sm font-medium truncate">Usuario Activo</p>
            <p className="text-xs text-slate-400 truncate">{usuarioActual}</p>
          </div>
        </div>
      </div>
    </div>
  );
}
