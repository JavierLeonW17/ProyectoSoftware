import { useState } from 'react';
import { Search, Filter, Plus, MoreVertical, Eye } from 'lucide-react';
import { Ticket } from '../types/ticket';
import { ModalTicket } from './ModalTicket';
import { ModalDetalleTicket } from './ModalDetalleTicket';

interface VistaTicketsProps {
  tickets: Ticket[];
  onCrearTicket: (ticket: Partial<Ticket>) => void;
  onActualizarTicket: (id: number, ticket: Partial<Ticket>) => void;
}

export function VistaTickets({ tickets, onCrearTicket, onActualizarTicket }: VistaTicketsProps) {
  const [terminoBusqueda, setTerminoBusqueda] = useState('');
  const [filtroEstado, setFiltroEstado] = useState('todos');
  const [modalCrearAbierto, setModalCrearAbierto] = useState(false);
  const [ticketSeleccionado, setTicketSeleccionado] = useState<Ticket | null>(null);
  const [modalDetalleAbierto, setModalDetalleAbierto] = useState(false);

  const ticketsFiltrados = tickets.filter((ticket) => {
    const coincideBusqueda =
      ticket.titulo.toLowerCase().includes(terminoBusqueda.toLowerCase()) ||
      ticket.descripcion.toLowerCase().includes(terminoBusqueda.toLowerCase()) ||
      ticket.id.toString().includes(terminoBusqueda);

    const coincideEstado = filtroEstado === 'todos' || ticket.estado === filtroEstado;

    return coincideBusqueda && coincideEstado;
  });

  const manejarVerDetalles = (ticket: Ticket) => {
    setTicketSeleccionado(ticket);
    setModalDetalleAbierto(true);
  };

  const manejarActualizarTicket = (datosTicket: Partial<Ticket>) => {
    if (ticketSeleccionado) {
      onActualizarTicket(ticketSeleccionado.id, datosTicket);
    }
  };

  return (
    <div className="flex-1 bg-gray-50 overflow-auto">
      <div className="p-8">
        {/* Encabezado */}
        <div className="flex items-center justify-between mb-8">
          <div>
            <h1 className="font-bold text-gray-900">Gestión de Tickets</h1>
            <p className="text-sm text-gray-600 mt-1">
              {ticketsFiltrados.length} tickets encontrados
            </p>
          </div>
          <button
            onClick={() => setModalCrearAbierto(true)}
            className="flex items-center gap-2 px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors"
          >
            <Plus className="w-5 h-5" />
            Nuevo Ticket
          </button>
        </div>

        {/* Filtros */}
        <div className="bg-white rounded-lg border border-gray-200 p-4 mb-6">
          <div className="flex flex-col sm:flex-row gap-4">
            <div className="flex-1 relative">
              <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
              <input
                type="text"
                placeholder="Buscar tickets..."
                value={terminoBusqueda}
                onChange={(e) => setTerminoBusqueda(e.target.value)}
                className="w-full pl-10 pr-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              />
            </div>
            <div className="flex items-center gap-2">
              <Filter className="w-5 h-5 text-gray-400" />
              <select
                value={filtroEstado}
                onChange={(e) => setFiltroEstado(e.target.value)}
                className="px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
              >
                <option value="todos">Todos los estados</option>
                <option value="nuevo">Nuevo</option>
                <option value="en-progreso">En Progreso</option>
                <option value="resuelto">Resuelto</option>
                <option value="cerrado">Cerrado</option>
              </select>
            </div>
          </div>
        </div>

        {/* Tabla de Tickets */}
        <div className="bg-white rounded-lg border border-gray-200 overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Título
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Prioridad
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Estado
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Asignado
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Categoría
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Fecha
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Acciones
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {ticketsFiltrados.map((ticket) => (
                  <tr key={ticket.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      #{ticket.id}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900 max-w-xs">
                      <div className="font-medium">{ticket.titulo}</div>
                      <div className="text-gray-500 truncate">{ticket.descripcion}</div>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 py-1 text-xs font-medium rounded-full ${
                          ticket.prioridad === 'alta'
                            ? 'bg-red-100 text-red-800'
                            : ticket.prioridad === 'media'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-green-100 text-green-800'
                        }`}
                      >
                        {ticket.prioridad.toUpperCase()}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 py-1 text-xs font-medium rounded-full ${
                          ticket.estado === 'nuevo'
                            ? 'bg-blue-100 text-blue-800'
                            : ticket.estado === 'en-progreso'
                            ? 'bg-purple-100 text-purple-800'
                            : ticket.estado === 'resuelto'
                            ? 'bg-green-100 text-green-800'
                            : 'bg-gray-100 text-gray-800'
                        }`}
                      >
                        {ticket.estado.replace('-', ' ').toUpperCase()}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                      {ticket.asignado}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {ticket.categoria || '-'}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {new Date(ticket.fecha).toLocaleDateString('es-ES')}
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      <div className="flex items-center gap-2">
                        <button
                          onClick={() => manejarVerDetalles(ticket)}
                          className="p-1 hover:bg-gray-100 rounded"
                          title="Ver detalles"
                        >
                          <Eye className="w-4 h-4 text-gray-600" />
                        </button>
                        <button className="p-1 hover:bg-gray-100 rounded">
                          <MoreVertical className="w-4 h-4 text-gray-600" />
                        </button>
                      </div>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          {ticketsFiltrados.length === 0 && (
            <div className="p-12 text-center">
              <p className="text-gray-500">No se encontraron tickets</p>
            </div>
          )}
        </div>
      </div>

      {/* Modal Crear */}
      <ModalTicket
        estaAbierto={modalCrearAbierto}
        onCerrar={() => setModalCrearAbierto(false)}
        onGuardar={onCrearTicket}
        ticket={null}
        modo="crear"
      />

      {/* Modal Detalle */}
      {ticketSeleccionado && (
        <ModalDetalleTicket
          estaAbierto={modalDetalleAbierto}
          onCerrar={() => {
            setModalDetalleAbierto(false);
            setTicketSeleccionado(null);
          }}
          ticket={ticketSeleccionado}
          onActualizar={manejarActualizarTicket}
        />
      )}
    </div>
  );
}
