import { useState } from 'react';
import { X, User, Calendar, Tag, MessageSquare, Clock } from 'lucide-react';
import { Ticket, TicketStatus } from '../types/ticket';

interface ModalDetalleTicketProps {
  estaAbierto: boolean;
  onCerrar: () => void;
  ticket: Ticket;
  onActualizar: (datosTicket: Partial<Ticket>) => void;
}

interface Comentario {
  id: number;
  autor: string;
  texto: string;
  fecha: string;
}

export function ModalDetalleTicket({ estaAbierto, onCerrar, ticket, onActualizar }: ModalDetalleTicketProps) {
  const [estado, setEstado] = useState(ticket.estado);
  const [comentarios, setComentarios] = useState<Comentario[]>([
    {
      id: 1,
      autor: 'Ana García',
      texto: 'He revisado el problema y estoy trabajando en la solución.',
      fecha: '2026-04-28 10:30',
    },
    {
      id: 2,
      autor: 'Carlos Ruiz',
      texto: 'Se requiere acceso adicional al servidor para completar la tarea.',
      fecha: '2026-04-28 14:15',
    },
  ]);
  const [nuevoComentario, setNuevoComentario] = useState('');

  const manejarCambioEstado = (nuevoEstado: TicketStatus) => {
    setEstado(nuevoEstado);
    onActualizar({ estado: nuevoEstado });
  };

  const manejarAgregarComentario = () => {
    if (nuevoComentario.trim()) {
      const comentario: Comentario = {
        id: comentarios.length + 1,
        autor: 'Usuario Actual',
        texto: nuevoComentario,
        fecha: new Date().toLocaleString('es-ES'),
      };
      setComentarios([...comentarios, comentario]);
      setNuevoComentario('');
    }
  };

  if (!estaAbierto) return null;

  return (
    <div className="fixed inset-0 bg-black bg-opacity-50 flex items-center justify-center z-50 p-4">
      <div className="bg-white rounded-lg max-w-4xl w-full max-h-[90vh] overflow-y-auto">
        {/* Encabezado */}
        <div className="sticky top-0 bg-white border-b border-gray-200 px-6 py-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <h2 className="font-bold text-gray-900">Ticket #{ticket.id}</h2>
            <span
              className={`px-3 py-1 text-xs font-medium rounded-full ${
                estado === 'nuevo'
                  ? 'bg-blue-100 text-blue-800'
                  : estado === 'en-progreso'
                  ? 'bg-purple-100 text-purple-800'
                  : estado === 'resuelto'
                  ? 'bg-green-100 text-green-800'
                  : 'bg-gray-100 text-gray-800'
              }`}
            >
              {estado.replace('-', ' ').toUpperCase()}
            </span>
          </div>
          <button onClick={onCerrar} className="text-gray-400 hover:text-gray-600">
            <X className="w-5 h-5" />
          </button>
        </div>

        <div className="p-6">
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
            {/* Contenido Principal */}
            <div className="lg:col-span-2 space-y-6">
              {/* Título y Descripción */}
              <div>
                <h3 className="font-semibold text-gray-900 mb-3">{ticket.titulo}</h3>
                <p className="text-sm text-gray-600 leading-relaxed">{ticket.descripcion}</p>
              </div>

              {/* Actualizar Estado */}
              <div className="border-t border-gray-200 pt-6">
                <label className="block text-sm font-medium text-gray-700 mb-2">
                  Actualizar Estado
                </label>
                <div className="flex gap-2">
                  {(['nuevo', 'en-progreso', 'resuelto', 'cerrado'] as TicketStatus[]).map(
                    (opcionEstado) => (
                      <button
                        key={opcionEstado}
                        onClick={() => manejarCambioEstado(opcionEstado)}
                        className={`px-4 py-2 text-sm font-medium rounded-lg transition-colors ${
                          estado === opcionEstado
                            ? 'bg-blue-600 text-white'
                            : 'bg-gray-100 text-gray-700 hover:bg-gray-200'
                        }`}
                      >
                        {opcionEstado.replace('-', ' ')}
                      </button>
                    )
                  )}
                </div>
              </div>

              {/* Sección de Comentarios */}
              <div className="border-t border-gray-200 pt-6">
                <h4 className="font-semibold text-gray-900 mb-4 flex items-center gap-2">
                  <MessageSquare className="w-5 h-5" />
                  Comentarios ({comentarios.length})
                </h4>

                <div className="space-y-4 mb-4">
                  {comentarios.map((comentario) => (
                    <div key={comentario.id} className="bg-gray-50 rounded-lg p-4">
                      <div className="flex items-center justify-between mb-2">
                        <span className="font-medium text-sm text-gray-900">
                          {comentario.autor}
                        </span>
                        <span className="text-xs text-gray-500">{comentario.fecha}</span>
                      </div>
                      <p className="text-sm text-gray-600">{comentario.texto}</p>
                    </div>
                  ))}
                </div>

                {/* Agregar Comentario */}
                <div className="space-y-2">
                  <textarea
                    value={nuevoComentario}
                    onChange={(e) => setNuevoComentario(e.target.value)}
                    placeholder="Agregar un comentario..."
                    rows={3}
                    className="w-full px-3 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                  />
                  <button
                    onClick={manejarAgregarComentario}
                    disabled={!nuevoComentario.trim()}
                    className="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition-colors disabled:bg-gray-300 disabled:cursor-not-allowed"
                  >
                    Agregar Comentario
                  </button>
                </div>
              </div>
            </div>

            {/* Barra Lateral */}
            <div className="space-y-6">
              {/* Tarjeta de Detalles */}
              <div className="bg-gray-50 rounded-lg p-4 space-y-4">
                <h4 className="font-semibold text-gray-900">Detalles del Ticket</h4>

                <div className="space-y-3">
                  <div className="flex items-start gap-3">
                    <User className="w-5 h-5 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-500">Asignado a</p>
                      <p className="text-sm font-medium text-gray-900">{ticket.asignado}</p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Calendar className="w-5 h-5 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-500">Fecha de creación</p>
                      <p className="text-sm font-medium text-gray-900">
                        {new Date(ticket.fecha).toLocaleDateString('es-ES', {
                          year: 'numeric',
                          month: 'long',
                          day: 'numeric',
                        })}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Tag className="w-5 h-5 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-500">Categoría</p>
                      <p className="text-sm font-medium text-gray-900">
                        {ticket.categoria || 'Sin categoría'}
                      </p>
                    </div>
                  </div>

                  <div className="flex items-start gap-3">
                    <Clock className="w-5 h-5 text-gray-400 mt-0.5" />
                    <div>
                      <p className="text-xs text-gray-500">Prioridad</p>
                      <span
                        className={`inline-block px-2 py-1 text-xs font-medium rounded-full ${
                          ticket.prioridad === 'alta'
                            ? 'bg-red-100 text-red-800'
                            : ticket.prioridad === 'media'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-green-100 text-green-800'
                        }`}
                      >
                        {ticket.prioridad.toUpperCase()}
                      </span>
                    </div>
                  </div>
                </div>
              </div>

              {/* Línea de Tiempo de Actividad */}
              <div className="bg-gray-50 rounded-lg p-4">
                <h4 className="font-semibold text-gray-900 mb-3">Actividad Reciente</h4>
                <div className="space-y-3">
                  <div className="flex gap-3">
                    <div className="w-2 h-2 bg-blue-600 rounded-full mt-1.5" />
                    <div>
                      <p className="text-sm text-gray-900">Ticket creado</p>
                      <p className="text-xs text-gray-500">Hace 2 días</p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="w-2 h-2 bg-purple-600 rounded-full mt-1.5" />
                    <div>
                      <p className="text-sm text-gray-900">Asignado a {ticket.asignado}</p>
                      <p className="text-xs text-gray-500">Hace 1 día</p>
                    </div>
                  </div>
                  <div className="flex gap-3">
                    <div className="w-2 h-2 bg-green-600 rounded-full mt-1.5" />
                    <div>
                      <p className="text-sm text-gray-900">Estado actualizado</p>
                      <p className="text-xs text-gray-500">Hace 3 horas</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
