import { useState } from 'react';
import { Mail, Lock, Eye, EyeOff, ArrowRight, Shield, AlertTriangle } from 'lucide-react';
import { Usuario, LogAcceso } from '../types/usuario';
import { hashPassword, verificarPassword, detectarAccesoSospechoso, registrarLog } from '../utils/seguridad';

interface InicioSesionMejoradoProps {
  onIniciarSesion: (usuario: Usuario) => void;
  usuarios: Usuario[];
  logs: LogAcceso[];
  onActualizarLogs: (logs: LogAcceso[]) => void;
}

export function InicioSesionMejorado({ onIniciarSesion, usuarios, logs, onActualizarLogs }: InicioSesionMejoradoProps) {
  const [vistaActual, setVistaActual] = useState<'login' | 'registro' | 'recuperar'>('login');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [mostrarPassword, setMostrarPassword] = useState(false);
  const [error, setError] = useState('');
  const [advertenciaSospechoso, setAdvertenciaSospechoso] = useState(false);

  const manejarSubmitLogin = (e: React.FormEvent) => {
    e.preventDefault();
    setError('');
    setAdvertenciaSospechoso(false);

    if (!email || !password) {
      setError('Por favor, completa todos los campos');
      return;
    }

    // Buscar usuario
    const usuario = usuarios.find((u) => u.email === email && u.activo);

    if (!usuario) {
      const nuevoLog = registrarLog(logs, 0, email, false, false);
      onActualizarLogs(nuevoLog);
      setError('Credenciales incorrectas o cuenta inactiva');
      return;
    }

    // Verificar contraseña (en este demo usamos una verificación simple)
    const passwordsDemo: { [key: string]: string } = {
      'admin@techhub.com': 'admin123',
      'agente@techhub.com': 'agente123',
      'usuario@techhub.com': 'usuario123',
    };

    if (passwordsDemo[email] !== password) {
      const nuevoLog = registrarLog(logs, usuario.id, email, false, false);
      onActualizarLogs(nuevoLog);
      setError('Credenciales incorrectas');
      return;
    }

    // Detectar acceso sospechoso
    const { sospechoso, razon } = detectarAccesoSospechoso(email, logs);

    if (sospechoso) {
      setAdvertenciaSospechoso(true);
      const nuevoLog = registrarLog(logs, usuario.id, email, true, true, razon);
      onActualizarLogs(nuevoLog);

      // Continuar con el inicio de sesión pero mostrar advertencia
      setTimeout(() => {
        onIniciarSesion(usuario);
      }, 2000);
    } else {
      const nuevoLog = registrarLog(logs, usuario.id, email, true, false);
      onActualizarLogs(nuevoLog);
      onIniciarSesion(usuario);
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-600 via-indigo-600 to-purple-700 flex items-center justify-center p-4">
      <div className="w-full max-w-md">
        {/* Logo y Header */}
        <div className="text-center mb-8">
          <div className="inline-block bg-white rounded-2xl p-4 mb-4 shadow-2xl">
            <div className="w-16 h-16 bg-gradient-to-br from-blue-600 to-indigo-700 rounded-xl flex items-center justify-center">
              <Shield className="w-10 h-10 text-white" />
            </div>
          </div>
          <h1 className="text-4xl font-bold text-white mb-2">TechHub Support</h1>
          <p className="text-blue-100">Sistema de Gestión de Tickets</p>
        </div>

        {/* Formulario */}
        <div className="bg-white rounded-2xl shadow-2xl p-8">
          {vistaActual === 'login' && (
            <>
              <div className="mb-6">
                <h2 className="text-2xl font-bold text-gray-900 mb-2">Iniciar Sesión</h2>
                <p className="text-sm text-gray-600">
                  Accede al sistema de forma segura
                </p>
              </div>

              <form onSubmit={manejarSubmitLogin} className="space-y-4">
                {error && (
                  <div className="bg-red-50 border border-red-200 text-red-700 px-4 py-3 rounded-lg text-sm flex items-start gap-2">
                    <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <span>{error}</span>
                  </div>
                )}

                {advertenciaSospechoso && (
                  <div className="bg-yellow-50 border border-yellow-200 text-yellow-800 px-4 py-3 rounded-lg text-sm flex items-start gap-2">
                    <AlertTriangle className="w-5 h-5 flex-shrink-0 mt-0.5" />
                    <div>
                      <p className="font-semibold">Acceso sospechoso detectado</p>
                      <p className="text-xs mt-1">Este inicio de sesión ha sido registrado por seguridad. Iniciando sesión...</p>
                    </div>
                  </div>
                )}

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Correo Electrónico
                  </label>
                  <div className="relative">
                    <Mail className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type="email"
                      value={email}
                      onChange={(e) => setEmail(e.target.value)}
                      className="w-full pl-10 pr-4 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="tu@email.com"
                    />
                  </div>
                </div>

                <div>
                  <label className="block text-sm font-medium text-gray-700 mb-2">
                    Contraseña
                  </label>
                  <div className="relative">
                    <Lock className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-gray-400" />
                    <input
                      type={mostrarPassword ? 'text' : 'password'}
                      value={password}
                      onChange={(e) => setPassword(e.target.value)}
                      className="w-full pl-10 pr-12 py-3 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500"
                      placeholder="••••••••"
                    />
                    <button
                      type="button"
                      onClick={() => setMostrarPassword(!mostrarPassword)}
                      className="absolute right-3 top-1/2 -translate-y-1/2 text-gray-400 hover:text-gray-600"
                    >
                      {mostrarPassword ? (
                        <EyeOff className="w-5 h-5" />
                      ) : (
                        <Eye className="w-5 h-5" />
                      )}
                    </button>
                  </div>
                </div>

                <button
                  type="submit"
                  className="w-full bg-gradient-to-r from-blue-600 to-indigo-600 text-white py-3 rounded-lg hover:from-blue-700 hover:to-indigo-700 transition-colors font-medium flex items-center justify-center gap-2"
                >
                  Iniciar Sesión
                  <ArrowRight className="w-5 h-5" />
                </button>
              </form>

              <div className="mt-6 pt-6 border-t border-gray-200">
                <p className="text-xs font-semibold text-gray-700 text-center mb-3">
                  Usuarios de demostración:
                </p>
                <div className="space-y-2 text-xs text-gray-600 bg-gray-50 p-3 rounded-lg">
                  <div className="flex justify-between">
                    <span className="font-medium">Administrador:</span>
                    <span>admin@techhub.com / admin123</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Agente:</span>
                    <span>agente@techhub.com / agente123</span>
                  </div>
                  <div className="flex justify-between">
                    <span className="font-medium">Usuario:</span>
                    <span>usuario@techhub.com / usuario123</span>
                  </div>
                </div>
                <p className="text-xs text-gray-500 text-center mt-3">
                  <Shield className="w-3 h-3 inline mr-1" />
                  Las contraseñas están encriptadas y los accesos son monitoreados
                </p>
              </div>
            </>
          )}
        </div>

        {/* Footer */}
        <div className="text-center mt-8">
          <p className="text-sm text-blue-100">
            © 2026 TechHub Support. Todos los derechos reservados.
          </p>
          <p className="text-xs text-blue-200 mt-1">
            Sistema seguro con detección de accesos sospechosos
          </p>
        </div>
      </div>
    </div>
  );
}
