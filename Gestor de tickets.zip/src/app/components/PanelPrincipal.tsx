import { TrendingUp, TrendingDown, Clock, CheckCircle } from 'lucide-react';
import { PieChart, Pie, Cell, ResponsiveContainer, BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, Legend } from 'recharts';

const datosEstadisticas = [
  { titulo: 'Total Tickets', valor: '156', cambio: '+12%', tendencia: 'arriba', icono: Clock, color: 'blue' },
  { titulo: 'Abiertos', valor: '42', cambio: '+5%', tendencia: 'arriba', icono: Clock, color: 'orange' },
  { titulo: 'En Progreso', valor: '38', cambio: '-3%', tendencia: 'abajo', icono: Clock, color: 'purple' },
  { titulo: 'Resueltos', valor: '76', cambio: '+8%', tendencia: 'arriba', icono: CheckCircle, color: 'green' },
];

const datosPrioridad = [
  { id: 'prioridad-alta', nombre: 'Alta', valor: 35, color: '#EF4444' },
  { id: 'prioridad-media', nombre: 'Media', valor: 68, color: '#F59E0B' },
  { id: 'prioridad-baja', nombre: 'Baja', valor: 53, color: '#10B981' },
];

const datosSemanal = [
  { id: 'semana-lun', dia: 'Lun', nuevos: 12, resueltos: 8 },
  { id: 'semana-mar', dia: 'Mar', nuevos: 15, resueltos: 10 },
  { id: 'semana-mie', dia: 'Mié', nuevos: 8, resueltos: 14 },
  { id: 'semana-jue', dia: 'Jue', nuevos: 18, resueltos: 12 },
  { id: 'semana-vie', dia: 'Vie', nuevos: 14, resueltos: 16 },
  { id: 'semana-sab', dia: 'Sáb', nuevos: 6, resueltos: 4 },
  { id: 'semana-dom', dia: 'Dom', nuevos: 4, resueltos: 2 },
];

const ticketsRecientes = [
  { id: '#1234', titulo: 'Error en sistema de pagos', prioridad: 'Alta', estado: 'Abierto', tiempo: 'Hace 5 min' },
  { id: '#1233', titulo: 'Solicitud de acceso VPN', prioridad: 'Media', estado: 'En Progreso', tiempo: 'Hace 15 min' },
  { id: '#1232', titulo: 'Actualización de software', prioridad: 'Baja', estado: 'Resuelto', tiempo: 'Hace 1 hora' },
  { id: '#1231', titulo: 'Problema con impresora', prioridad: 'Media', estado: 'En Progreso', tiempo: 'Hace 2 horas' },
];

export function PanelPrincipal() {
  return (
    <div className="flex-1 bg-gray-50 overflow-auto">
      <div className="p-8">
        {/* Encabezado */}
        <div className="mb-8">
          <div className="flex items-center gap-3 mb-2">
            <div className="w-12 h-12 bg-gradient-to-br from-blue-500 to-indigo-600 rounded-xl flex items-center justify-center">
              <span className="font-bold text-white text-lg">TH</span>
            </div>
            <div>
              <h1 className="font-bold text-gray-900">Panel Principal de TechHub</h1>
              <p className="text-sm text-gray-600">Sistema de Gestión de Tickets</p>
            </div>
          </div>
        </div>

        {/* Tarjetas de Estadísticas */}
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6 mb-8">
          {datosEstadisticas.map((stat) => {
            const Icono = stat.icono;
            const IconoTendencia = stat.tendencia === 'arriba' ? TrendingUp : TrendingDown;
            const colorFondoIcono = stat.color === 'blue' ? 'bg-blue-100' :
                               stat.color === 'orange' ? 'bg-orange-100' :
                               stat.color === 'purple' ? 'bg-purple-100' : 'bg-green-100';
            const colorIcono = stat.color === 'blue' ? 'text-blue-600' :
                             stat.color === 'orange' ? 'text-orange-600' :
                             stat.color === 'purple' ? 'text-purple-600' : 'text-green-600';
            return (
              <div key={stat.titulo} className="bg-white rounded-lg p-6 border border-gray-200">
                <div className="flex items-center justify-between mb-4">
                  <div className={`w-12 h-12 rounded-lg ${colorFondoIcono} flex items-center justify-center`}>
                    <Icono className={`w-6 h-6 ${colorIcono}`} />
                  </div>
                  <div className={`flex items-center gap-1 text-sm ${
                    stat.tendencia === 'arriba' ? 'text-green-600' : 'text-red-600'
                  }`}>
                    <IconoTendencia className="w-4 h-4" />
                    {stat.cambio}
                  </div>
                </div>
                <p className="text-sm text-gray-600 mb-1">{stat.titulo}</p>
                <p className="font-bold text-gray-900">{stat.valor}</p>
              </div>
            );
          })}
        </div>

        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mb-8">
          {/* Distribución por Prioridad */}
          <div className="bg-white rounded-lg p-6 border border-gray-200">
            <h3 className="font-semibold text-gray-900 mb-4">Distribución por Prioridad</h3>
            <ResponsiveContainer width="100%" height={200}>
              <PieChart>
                <Pie
                  data={datosPrioridad}
                  cx="50%"
                  cy="50%"
                  innerRadius={60}
                  outerRadius={80}
                  paddingAngle={5}
                  dataKey="valor"
                  nameKey="nombre"
                >
                  {datosPrioridad.map((entrada) => (
                    <Cell key={entrada.id} fill={entrada.color} />
                  ))}
                </Pie>
              </PieChart>
            </ResponsiveContainer>
            <div className="mt-4 space-y-2">
              {datosPrioridad.map((elemento) => (
                <div key={elemento.id} className="flex items-center justify-between text-sm">
                  <div className="flex items-center gap-2">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: elemento.color }} />
                    <span className="text-gray-600">{elemento.nombre}</span>
                  </div>
                  <span className="font-medium text-gray-900">{elemento.valor}</span>
                </div>
              ))}
            </div>
          </div>

          {/* Actividad Semanal */}
          <div className="bg-white rounded-lg p-6 border border-gray-200 lg:col-span-2">
            <h3 className="font-semibold text-gray-900 mb-4">Actividad Semanal</h3>
            <ResponsiveContainer width="100%" height={200}>
              <BarChart data={datosSemanal}>
                <CartesianGrid strokeDasharray="3 3" stroke="#f0f0f0" />
                <XAxis dataKey="dia" tick={{ fontSize: 12 }} />
                <YAxis tick={{ fontSize: 12 }} />
                <Tooltip />
                <Legend />
                <Bar dataKey="nuevos" name="Nuevos" fill="#3B82F6" radius={[4, 4, 0, 0]} key="barra-nuevos" />
                <Bar dataKey="resueltos" name="Resueltos" fill="#10B981" radius={[4, 4, 0, 0]} key="barra-resueltos" />
              </BarChart>
            </ResponsiveContainer>
          </div>
        </div>

        {/* Tickets Recientes */}
        <div className="bg-white rounded-lg border border-gray-200">
          <div className="p-6 border-b border-gray-200">
            <h3 className="font-semibold text-gray-900">Tickets Recientes</h3>
          </div>
          <div className="overflow-x-auto">
            <table className="w-full">
              <thead className="bg-gray-50 border-b border-gray-200">
                <tr>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    ID
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Título
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Prioridad
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Estado
                  </th>
                  <th className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                    Tiempo
                  </th>
                </tr>
              </thead>
              <tbody className="bg-white divide-y divide-gray-200">
                {ticketsRecientes.map((ticket) => (
                  <tr key={ticket.id} className="hover:bg-gray-50">
                    <td className="px-6 py-4 whitespace-nowrap text-sm font-medium text-gray-900">
                      {ticket.id}
                    </td>
                    <td className="px-6 py-4 text-sm text-gray-900">{ticket.titulo}</td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 py-1 text-xs font-medium rounded-full ${
                          ticket.prioridad === 'Alta'
                            ? 'bg-red-100 text-red-800'
                            : ticket.prioridad === 'Media'
                            ? 'bg-yellow-100 text-yellow-800'
                            : 'bg-green-100 text-green-800'
                        }`}
                      >
                        {ticket.prioridad}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap">
                      <span
                        className={`px-2 py-1 text-xs font-medium rounded-full ${
                          ticket.estado === 'Abierto'
                            ? 'bg-blue-100 text-blue-800'
                            : ticket.estado === 'En Progreso'
                            ? 'bg-purple-100 text-purple-800'
                            : 'bg-green-100 text-green-800'
                        }`}
                      >
                        {ticket.estado}
                      </span>
                    </td>
                    <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-500">
                      {ticket.tiempo}
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
