import { Usuario, LogAcceso } from '../types/usuario';

export const usuariosIniciales: Usuario[] = [
  {
    id: 1,
    nombre: 'Admin Principal',
    email: 'admin@techhub.com',
    rol: 'administrador',
    activo: true,
    fechaCreacion: '2026-01-01',
  },
  {
    id: 2,
    nombre: 'Agente de Soporte',
    email: 'agente@techhub.com',
    rol: 'agente',
    activo: true,
    fechaCreacion: '2026-01-15',
  },
  {
    id: 3,
    nombre: 'Usuario Normal',
    email: 'usuario@techhub.com',
    rol: 'usuario',
    activo: true,
    fechaCreacion: '2026-02-01',
  },
];

export const logsIniciales: LogAcceso[] = [];
